<?php
$dp_servername = "localhost";
$dp_username = "root";
$dp_password = "";
$dp_name = "Shopping_data"
$dp_port = "3306"

// Create connection
$conn = new mysqli($dp_servername, $dp_username, $dp_password,$dp_name,$dp_port);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>