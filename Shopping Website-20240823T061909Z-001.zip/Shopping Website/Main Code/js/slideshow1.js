var arr_images = ["images/sh.png","images/sh1.png"];
		var i = 0;
		function slide1()
		{
			document.getElementById("ban").src = arr_images[i];
			if(i<arr_images.length-1)
			{
				i++;
			}
			else
			{
				i=0;
			}
			setTimeout('slide1()',2000);
		}
		